
import { useState } from 'react';
import './App.css';

import Exam1 from './components/Exam1_SmartTaskCounter';
import Exam2 from './components/Exam2_LiveSearchTimer';
import Exam3 from './components/Exam3_AccessibleForm';
import Exam4 from './components/Exam4_ApplicationPreferences';
import Exam5 from './components/Exam5_ProductExplorer';
import Exam6 from './components/Exam6_IssueTracker';

const exams = [
  { id: 1, title: 'Smart Task Counter', component: Exam1 },
  { id: 2, title: 'Live Search and Timer', component: Exam2 },
  { id: 3, title: 'Accessible Form Toolkit', component: Exam3 },
  { id: 4, title: 'Application Preferences', component: Exam4 },
  { id: 5, title: 'Product Explorer', component: Exam5 },
  { id: 6, title: 'Issue Tracker', component: Exam6 },
];

function App() {
  const [activeExam, setActiveExam] = useState(1);

  const selectedExam = exams.find(
    (exam) => exam.id === activeExam
  );

  const ActiveComponent = selectedExam.component;

  return (
    <div className="app">
      <header className="app-header">
        <p className="eyebrow">CSIT340 MIDTERM EXAM</p>
        <h1>React Hooks Exam</h1>
      </header>

      <nav className="exam-navigation" aria-label="Practical exams">
        {exams.map((exam) => (
          <button
            key={exam.id}
            className={
              activeExam === exam.id
                ? 'nav-button active'
                : 'nav-button'
            }
            aria-current={activeExam === exam.id ? 'page' : undefined}
            onClick={() => setActiveExam(exam.id)}
          >
            <span>Exam {exam.id}</span>
            {exam.title}
          </button>
        ))}
      </nav>

      <main className="exam-content">
        <ActiveComponent key={activeExam} />
      </main>

      <footer className="app-footer">
        Submitted By Rothesa V. Arcena
      </footer>
    </div>
  );
}

export default App;
