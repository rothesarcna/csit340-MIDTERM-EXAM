
import { useState } from 'react';

function Exam1_SmartTaskCounter() {
  const [count, setCount] = useState(0);
  const [target, setTarget] = useState(5);

  const status =
    count === 0
      ? 'Not started'
      : count >= target
      ? 'Target reached'
      : 'In progress';

  const increment = () => {
    setCount((c) => c + 1);
  };

  const decrement = () => {
    setCount((c) => Math.max(0, c - 1));
  };

  const addTwo = () => {
    setCount((c) => Math.min(c + 1, target));
    setCount((c) => Math.min(c + 1, target));
  };

  const reset = () => {
    setCount(0);
  };

  return (
    <section className="task-counter">
      <h2>Exam 1: Smart Task Counter</h2>

      <p>Practice useState, functional updates, and derived state.</p>

      <div className="counter-settings">
        <label htmlFor="target">Target:</label>
        <input
          id="target"
          type="number"
          min="1"
          value={target}
          onChange={(event) => {
            const value = Number(event.target.value);

            if (value >= 1) {
              setTarget(value);
            }
          }}
        />
      </div>

      <div className="counter-display">
        <p>Completed Tasks: {count}</p>
        <p>Target: {target}</p>
        <p>Status: {status}</p>
      </div>

      <div className="counter-progress">
        <div
          className="counter-progress-bar"
          style={{
            width: `${Math.min((count / target) * 100, 100)}%`,
          }}
        />
      </div>

      {count >= target && (
        <p className="success-message">
          Great job! You reached your target.
        </p>
      )}

      <div className="counter-buttons">
        <button
          onClick={increment}
          disabled={count >= target}
        >
          Increment
        </button>

        <button onClick={decrement}>
          Decrement
        </button>

        <button
          onClick={addTwo}
          disabled={count >= target}
        >
          Plus Two
        </button>

        <button onClick={reset}>
          Reset
        </button>
      </div>

      <p className="exam-note">
        The status is calculated from count and target.
        It is not stored in a separate state variable.
      </p>
    </section>
  );
}

export default Exam1_SmartTaskCounter;
