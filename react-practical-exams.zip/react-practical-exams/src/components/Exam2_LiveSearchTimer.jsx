
import { useState, useEffect } from 'react';

const USERS = [
  { id: 1, name: 'Ana Cruz', role: 'Developer' },
  { id: 2, name: 'Ben Lim', role: 'Designer' },
  { id: 3, name: 'Cara Yu', role: 'Tester' },
  { id: 4, name: 'Dan Go', role: 'Developer' },
];

function Exam2_LiveSearchTimer() {
  const [query, setQuery] = useState('');
  const [visibleUsers, setVisibleUsers] = useState(USERS);
  const [seconds, setSeconds] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      const results = USERS.filter((user) =>
        user.name.toLowerCase().includes(query.toLowerCase())
      );

      setVisibleUsers(results);
    }, 300);

    return () => {
      clearTimeout(timer);
    };
  }, [query]);

  useEffect(() => {
    const interval = setInterval(() => {
      setSeconds((s) => s + 1);
    }, 1000);

    return () => {
      clearInterval(interval);
    };
  }, []);

  useEffect(() => {
    document.title = `${visibleUsers.length} Users Found`;
  }, [visibleUsers]);

  return (
    <section>
      <h2>Exam 2: Live Search and Timer</h2>

      <p>Session Time: {seconds} seconds</p>

      <input
        type="text"
        placeholder="Search users..."
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <p>Visible Users: {visibleUsers.length}</p>

      <div>
        {visibleUsers.map((user) => (
          <div className="user" key={user.id}>
            <h3>{user.name}</h3>
            <p>{user.role}</p>
          </div>
        ))}
      </div>

      {visibleUsers.length === 0 && (
        <p>No matching users found.</p>
      )}
    </section>
  );
}

export default Exam2_LiveSearchTimer;
