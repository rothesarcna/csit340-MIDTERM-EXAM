
import { useState, useRef } from 'react';

function Exam3_AccessibleForm() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errors, setErrors] = useState({});
  const [message, setMessage] = useState('');

  const nameRef = useRef(null);
  const emailRef = useRef(null);
  const passwordRef = useRef(null);
  const previousEmailRef = useRef('');

  function handleSubmit(e) {
    e.preventDefault();

    const newErrors = {};

    if (!name.trim()) {
      newErrors.name = 'Name is required.';
    }

    if (!email.trim()) {
      newErrors.email = 'Email is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      newErrors.email = 'Please enter a valid email address.';
    }

    if (!password) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters.';
    }

    setErrors(newErrors);
    setMessage('');

    if (newErrors.name) {
      nameRef.current.focus();
    } else if (newErrors.email) {
      emailRef.current.focus();
    } else if (newErrors.password) {
      passwordRef.current.focus();
    } else {
      const previousEmail = previousEmailRef.current;

      if (previousEmail) {
        setMessage(
          'Registration successful! Previous email: ' + previousEmail
        );
      } else {
        setMessage('Registration successful! No previous email.');
      }

      previousEmailRef.current = email;
    }
  }

  return (
    <section>
      <h2>Exam 3: Accessible Form Toolkit</h2>

      <p>Enter your details and submit the form.</p>

      <form onSubmit={handleSubmit} noValidate>
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            ref={nameRef}
            id="name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter your name"
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? 'name-error' : undefined}
          />

          {errors.name && (
            <p id="name-error" className="error-message">
              {errors.name}
            </p>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            ref={emailRef}
            id="email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? 'email-error' : undefined}
          />

          {errors.email && (
            <p id="email-error" className="error-message">
              {errors.email}
            </p>
          )}
        </div>

        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            ref={passwordRef}
            id="password"
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="At least 8 characters"
            aria-invalid={Boolean(errors.password)}
            aria-describedby={
              errors.password ? 'password-error' : undefined
            }
          />

          {errors.password && (
            <p id="password-error" className="error-message">
              {errors.password}
            </p>
          )}
        </div>

        <button type="submit">Register</button>

        {message && (
          <p className="success-message" role="status">
            {message}
          </p>
        )}
      </form>
    </section>
  );
}

export default Exam3_AccessibleForm;
