
import {
  createContext,
  useContext,
  useState,
} from 'react';

const PreferencesContext = createContext(null);

function PreferencesProvider({ children }) {
  const [theme, setTheme] = useState('light');
  const [fontSize, setFontSize] = useState(16);

  const value = {
    theme,
    fontSize,
    toggleTheme: () => {
      setTheme((previous) =>
        previous === 'light' ? 'dark' : 'light'
      );
    },
    setFontSize,
  };

  return (
    <PreferencesContext.Provider value={value}>
      {children}
    </PreferencesContext.Provider>
  );
}

function usePreferences() {
  const context = useContext(PreferencesContext);

  if (context === null) {
    throw new Error(
      'usePreferences must be used inside PreferencesProvider.'
    );
  }

  return context;
}

function Toolbar() {
  const { theme, toggleTheme } = usePreferences();

  return (
    <div className="toolbar">
      <span>Current theme: {theme}</span>
      <button onClick={toggleTheme}>
        Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
      </button>
    </div>
  );
}

function PreferencesPanel() {
  const { fontSize, setFontSize } = usePreferences();

  return (
    <div className="info-panel">
      <h3>Preferences</h3>
      <label htmlFor="font-size">Font size: </label>
      <select
        id="font-size"
        value={fontSize}
        onChange={(event) => setFontSize(Number(event.target.value))}
      >
        <option value={14}>14 px</option>
        <option value={16}>16 px</option>
        <option value={18}>18 px</option>
      </select>
    </div>
  );
}

function ArticlePreview() {
  const { theme, fontSize } = usePreferences();

  return (
    <article
      className={`article-preview ${theme}`}
      style={{ fontSize: `${fontSize}px` }}
    >
      <h3>Article Preview</h3>
      <p>
        This article uses the shared theme and font-size preferences.
        Changes in the toolbar and preferences panel update this preview.
      </p>
    </article>
  );
}

function Dashboard() {
  const { theme } = usePreferences();

  return (
    <section className={`preferences-dashboard ${theme}`}>
      <h2>Exam 4: Application Preferences</h2>
      <Toolbar />
      <PreferencesPanel />
      <ArticlePreview />
    </section>
  );
}

function Exam4_ApplicationPreferences() {
  return (
    <PreferencesProvider>
      <Dashboard />
    </PreferencesProvider>
  );
}

export default Exam4_ApplicationPreferences;
