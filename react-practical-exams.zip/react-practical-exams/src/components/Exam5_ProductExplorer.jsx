
import { useState, useMemo, useCallback, useEffect, memo } from "react";
import products from "../data/products";

const ProductCard = memo(function ProductCard({ product, onSelect }) {
  return (
    <div className="product-card">
      <h3>{product.name}</h3>
      <p>Category: {product.category}</p>
      <p>Price: ${product.price.toFixed(2)}</p>
      <p>Rating: {product.rating}/5</p>

      <button onClick={() => onSelect(product)}>
        View Product
      </button>
    </div>
  );
});

const ProductList = memo(function ProductList({ products, onSelect }) {
  console.log("ProductList rendered");

  if (products.length === 0) {
    return <p>No products found.</p>;
  }

  return (
    <div className="product-grid">
      {products.map((product) => (
        <ProductCard
          key={product.id}
          product={product}
          onSelect={onSelect}
        />
      ))}
    </div>
  );
});

function Exam5_ProductExplorer() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [sort, setSort] = useState("name");
  const [counter, setCounter] = useState(0);

  const handleSelect = useCallback((product) => {
    alert(`Selected: ${product.name}`);
  }, []);

  const sortedProducts = useMemo(() => {
    console.log("Filtering and sorting products");

    const filtered = products.filter((product) => {
      const matchesSearch = product.name
        .toLowerCase()
        .includes(search.toLowerCase());

      const matchesCategory =
        category === "All" || product.category === category;

      return matchesSearch && matchesCategory;
    });

    return [...filtered].sort((a, b) => {
      if (sort === "price") {
        return a.price - b.price;
      }

      if (sort === "rating") {
        return b.rating - a.rating;
      }

      return a.name.localeCompare(b.name);
    });
  }, [search, category, sort]);

  useEffect(() => {
    console.log("Product Explorer analytics:", {
      search,
      category,
      sort,
      results: sortedProducts.length,
    });
  }, [search, category, sort, sortedProducts.length]);

  return (
    <div className="app">
      <h1>Product Explorer</h1>
      <p>Explore and sort {products.length} sample products.</p>

      <div className="controls">
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />

        <select
          value={category}
          onChange={(e) => setCategory(e.target.value)}
        >
          <option value="All">All Categories</option>
          <option value="Electronics">Electronics</option>
          <option value="Clothing">Clothing</option>
          <option value="Home">Home</option>
          <option value="Sports">Sports</option>
          <option value="Books">Books</option>
        </select>

        <select
          value={sort}
          onChange={(e) => setSort(e.target.value)}
        >
          <option value="name">Sort by Name</option>
          <option value="price">Sort by Price</option>
          <option value="rating">Sort by Rating</option>
        </select>
      </div>

      <p>Products found: {sortedProducts.length}</p>

      <button onClick={() => setCounter((c) => c + 1)}>
        Counter: {counter}
      </button>

      <ProductList
        products={sortedProducts}
        onSelect={handleSelect}
      />
    </div>
  );
}

export default Exam5_ProductExplorer;
