
import { useState } from 'react';
import { usePersistentReducer } from '../hooks/usePersistentReducer';
import {
  initialIssueState,
  issueReducer,
} from '../reducers/issueReducer';

function Exam6_IssueTracker() {
  const [state, dispatch] = usePersistentReducer(
    issueReducer,
    initialIssueState,
    'react-practical-exam-issues'
  );

  const [title, setTitle] = useState('');

  const addIssue = (event) => {
    event.preventDefault();

    if (!title.trim()) {
      return;
    }

    dispatch({
      type: 'ADD_ISSUE',
      payload: { title: title.trim() },
    });

    setTitle('');
  };

  const openCount = state.issues.filter(
    (issue) => !issue.done
  ).length;

  const doneCount = state.issues.filter(
    (issue) => issue.done
  ).length;

  const visibleIssues = state.issues.filter((issue) => {
    if (state.filter === 'open') {
      return !issue.done;
    }

    if (state.filter === 'done') {
      return issue.done;
    }

    return true;
  });

  return (
    <section>
      <h2>Exam 6: Issue Tracker State Engine</h2>
      <p>Practice useReducer, custom Hooks, and local storage.</p>

      <form onSubmit={addIssue} className="issue-form">
        <label htmlFor="issue-title">New issue</label>

        <input
          id="issue-title"
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Describe an issue"
          required
        />

        <button type="submit">Add Issue</button>
      </form>

      <div className="issue-counts">
        <span>All: {state.issues.length}</span>
        <span>Open: {openCount}</span>
        <span>Done: {doneCount}</span>
      </div>

      <div className="button-row filter-buttons">
        <button
          type="button"
          className={state.filter === 'all' ? 'active-filter' : ''}
          onClick={() =>
            dispatch({
              type: 'SET_FILTER',
              payload: { filter: 'all' },
            })
          }
        >
          All
        </button>

        <button
          type="button"
          className={state.filter === 'open' ? 'active-filter' : ''}
          onClick={() =>
            dispatch({
              type: 'SET_FILTER',
              payload: { filter: 'open' },
            })
          }
        >
          Open
        </button>

        <button
          type="button"
          className={state.filter === 'done' ? 'active-filter' : ''}
          onClick={() =>
            dispatch({
              type: 'SET_FILTER',
              payload: { filter: 'done' },
            })
          }
        >
          Done
        </button>

        <button
          type="button"
          onClick={() => dispatch({ type: 'CLEAR_DONE' })}
          disabled={doneCount === 0}
        >
          Clear Done
        </button>
      </div>

      {visibleIssues.length === 0 ? (
        <p>No issues in this view.</p>
      ) : (
        <ul className="issue-list">
          {visibleIssues.map((issue) => (
            <li
              key={issue.id}
              className={issue.done ? 'issue-done' : ''}
            >
              <label>
                <input
                  type="checkbox"
                  checked={issue.done}
                  onChange={() =>
                    dispatch({
                      type: 'TOGGLE_ISSUE',
                      payload: { id: issue.id },
                    })
                  }
                />

                <span>{issue.title}</span>
              </label>

              <button
                type="button"
                className="delete-button"
                onClick={() =>
                  dispatch({
                    type: 'DELETE_ISSUE',
                    payload: { id: issue.id },
                  })
                }
                aria-label={`Delete ${issue.title}`}
              >
                Delete
              </button>
            </li>
          ))}
        </ul>
      )}

      <p className="muted">
        Issues are saved in this browser. Refresh the page to test persistence.
      </p>
    </section>
  );
}

export default Exam6_IssueTracker;
