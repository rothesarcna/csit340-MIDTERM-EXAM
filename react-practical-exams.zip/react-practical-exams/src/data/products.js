
const categories = ["Electronics", "Clothing", "Home", "Sports", "Books"];

const products = Array.from({ length: 500 }, (_, index) => ({
  id: index + 1,
  name: `Product ${index + 1}`,
  category: categories[index % categories.length],
  price: Number(
    (10 + ((index * 37) % 490) + (index % 10) / 10).toFixed(2)
  ),
  rating: 3 + (index % 3),
}));

export default products;
