
import { useEffect, useReducer } from 'react';

export function usePersistentReducer(
  reducer,
  initialState,
  storageKey
) {
  const [state, dispatch] = useReducer(
    reducer,
    initialState,
    (defaultState) => {
      try {
        const saved = localStorage.getItem(storageKey);

        return saved ? JSON.parse(saved) : defaultState;
      } catch {
        return defaultState;
      }
    }
  );

  useEffect(() => {
    try {
      localStorage.setItem(storageKey, JSON.stringify(state));
    } catch (error) {
      console.error('Could not save issue tracker state:', error);
    }
  }, [state, storageKey]);

  return [state, dispatch];
}
