
import test from 'node:test';
import assert from 'node:assert/strict';

import {
  initialIssueState,
  issueReducer,
} from './issueReducer.js';

test('ADD_ISSUE adds an issue and increments nextId', () => {
  const state = issueReducer(initialIssueState, {
    type: 'ADD_ISSUE',
    payload: { title: 'Fix login form' },
  });

  assert.equal(state.issues.length, 1);
  assert.equal(state.issues[0].title, 'Fix login form');
  assert.equal(state.issues[0].id, 1);
  assert.equal(state.nextId, 2);
});

test('TOGGLE_ISSUE changes an issue completion status', () => {
  const state = {
    ...initialIssueState,
    issues: [{ id: 1, title: 'Test app', done: false }],
  };

  const result = issueReducer(state, {
    type: 'TOGGLE_ISSUE',
    payload: { id: 1 },
  });

  assert.equal(result.issues[0].done, true);
  assert.equal(state.issues[0].done, false);
});

test('CLEAR_DONE removes completed issues only', () => {
  const state = {
    ...initialIssueState,
    issues: [
      { id: 1, title: 'Finished task', done: true },
      { id: 2, title: 'Unfinished task', done: false },
    ],
  };

  const result = issueReducer(state, { type: 'CLEAR_DONE' });

  assert.equal(result.issues.length, 1);
  assert.equal(result.issues[0].id, 2);
  assert.equal(state.issues.length, 2);
});
